
import { GoogleGenAI, GenerateImageResponse } from "@google/genai";

// Per instructions, API_KEY is assumed to be pre-configured and accessible
// via process.env.API_KEY in the execution context.

let ai: GoogleGenAI | null = null;

const getAiClient = (): GoogleGenAI => {
  if (!ai) {
    const apiKeyFromEnv = process.env.API_KEY;
    if (!apiKeyFromEnv) {
      // This error will be caught by the calling function in App.tsx
      // and displayed to the user.
      throw new Error("API Key is not configured. Please ensure the API_KEY environment variable is set.");
    }
    ai = new GoogleGenAI({ apiKey: apiKeyFromEnv });
  }
  return ai;
};

const MODEL_NAME = 'imagen-3.0-generate-002';

export const generatePixelArt = async (promptDetails: string): Promise<string> => {
  const client = getAiClient(); // This will throw if API_KEY is not set or client fails to initialize

  // Constructing a more general prompt to guide the AI for pixel art
  const fullPrompt = `Generate a highly detailed pixel art image. The subject is: "${promptDetails}". 
Ensure the pixel art style is crisp, with clear definition between elements. 
If the request implies a sprite sheet (e.g., mentions frames, animation, sequence), arrange the sprites or frames clearly, typically in a horizontal row or grid. 
If the request implies a tilemap (e.g., mentions top-down, grid, map tiles), ensure it has a clear grid-like structure suitable for a tilemap.
The overall aesthetic should be high-quality pixel art.`;

  try {
    const response: GenerateImageResponse = await client.models.generateImages({
      model: MODEL_NAME,
      prompt: fullPrompt,
      config: {
        numberOfImages: 1,
        outputMimeType: 'image/png',
        aspectRatio: "1:1" // Guides towards a square aspect ratio, common for pixel art assets.
      },
    });

    if (response.generatedImages && response.generatedImages.length > 0 && response.generatedImages[0].image?.imageBytes) {
      const base64ImageBytes = response.generatedImages[0].image.imageBytes;
      return `data:image/png;base64,${base64ImageBytes}`;
    } else {
      console.error("Gemini API response missing image data or malformed:", response);
      throw new Error("No image data received from the AI. The response might be empty or malformed. Please try again.");
    }
  } catch (error) {
    console.error("Error generating image with Gemini API:", error);
    if (error instanceof Error) {
        // Enhance error messages for better user understanding
        if (error.message.includes("API key not valid") || error.message.includes("API_KEY_INVALID") || error.message.includes("Api key not valid")) {
            throw new Error("The API key is invalid or missing. Please check your environment configuration.");
        }
        if (error.message.toLowerCase().includes("quota")) {
            throw new Error("API quota exceeded. Please try again later or check your quota limits with Google AI Studio.");
        }
        if (error.message.includes("Unsupported SADC region") || error.message.includes("LOCATION_POLICY_VIOLATED")) {
             throw new Error("The image generation service is not available in your region or has been restricted.");
        }
        if (error.message.includes("Deadline exceeded") || error.message.includes("timeout")) {
            throw new Error("The request timed out. The AI might be taking too long to respond. Please try again with a simpler prompt or later.");
        }
         if (error.message.includes("INTERNAL")) {
            throw new Error("An internal error occurred with the AI service. Please try again later.");
        }
        // For other errors, re-throw with a generic prefix but include original message
        throw new Error(`Image generation failed: ${error.message}`);
    }
    // Fallback for non-Error objects
    throw new Error("An unknown error occurred while generating the image. Please check the console for more details.");
  }
};
