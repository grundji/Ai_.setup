
import React from 'react';

interface ImageDisplayProps {
  src: string;
  alt: string;
}

export const ImageDisplay: React.FC<ImageDisplayProps> = ({ src, alt }) => {
  return (
    <div className="mt-6 bg-slate-700/50 p-2 rounded-lg shadow-lg ring-1 ring-slate-600">
      <img
        src={src}
        alt={alt}
        className="w-full h-auto rounded-md object-contain mx-auto block"
        style={{ imageRendering: 'pixelated' }} // Crucial for sharp pixel art
      />
       <p className="text-xs text-slate-400 text-center mt-2">
        Right-click or long-press to save the generated image.
      </p>
    </div>
  );
};
