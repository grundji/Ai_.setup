
import React from 'react';

interface PromptInputProps {
  value: string;
  onChange: (value: string) => void;
  disabled: boolean;
}

export const PromptInput: React.FC<PromptInputProps> = ({ value, onChange, disabled }) => {
  return (
    <div>
      <label htmlFor="prompt-details" className="block text-sm font-medium text-sky-300 mb-1">
        Describe your desired pixel art:
      </label>
      <textarea
        id="prompt-details"
        rows={4}
        className="w-full p-3 bg-slate-700 border border-slate-600 rounded-md shadow-sm focus:ring-2 focus:ring-sky-500 focus:border-sky-500 text-slate-100 placeholder-slate-400 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-150"
        placeholder="e.g., a cute cat, a spaceship sprite sheet (4 frames, side view), an enchanted forest tilemap..."
        value={value}
        onChange={(e) => onChange(e.target.value)}
        disabled={disabled}
        aria-describedby="prompt-helper-text"
      />
       <p id="prompt-helper-text" className="mt-1 text-xs text-slate-400">
        Be descriptive! For sprite sheets, mention frames or actions. For tilemaps, describe the environment.
      </p>
    </div>
  );
};
